
console.log(document.getElementById(urlMsg))

alert("12312")