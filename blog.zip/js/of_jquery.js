/*百度分享*/
window._bd_share_config={
		"common":
			{"bdSnsKey":
				{
					"tsina": "3185645315",
					"douban": "0741f32a7258ef8715c5d97f570ace95"
				},
				"bdText":"",
				"bdMini":"2",
				"bdPic":"",
				 "bdStyle":"0",
				"bdSize":"24"
			},
		"share":{}
	};
with(document)0[(getElementsByTagName('head')[0]||body)
.appendChild(createElement('script'))
.src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];


window.onload=canvas_func();


$(document).ready(function(){
	SyntaxHighlighter.config.clipboardSwf = 'http://static.oschina.net/js/syntax-highlighter-2.1.382/scripts/clipboard.swf';
	SyntaxHighlighter.all();
});